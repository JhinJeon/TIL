from . import views
from django.urls import path


urlpatterns = [
    path('artist/', views.artist_all),
    path('artist/<int:artist_pk>/', views.artist_detail),
    # path('artist/<int:artist_pk>/music/', views.artist_music),
    path('music/', views.music_all),
    path('music/<int:music_pk>/', views.music_detail),
]
