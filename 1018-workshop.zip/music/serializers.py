from rest_framework import serializers
from .models import Artist, Music

class ArtistListSerializer(serializers.ModelSerializer):

    class Meta:
        model = Artist
        fields = ('id', 'name',)


class MusicSerializer(serializers.ModelSerializer):

    class Meta:
        model = Music
        fields = '__all__'
        # read_only_fields는 model에 입력한 모델의 필드명을 기준으로 해야 한다
        read_only_fields = ('artist',)


class ArtistSerializer(serializers.ModelSerializer):
    music_set = MusicSerializer(many=True)
    # music_set = serializers.PrimaryKeyRelatedField(many=True, read_only = True)
    music_count = serializers.IntegerField(source='music_set.count', read_only = True)
    
    class Meta:
        model = Artist
        fields = '__all__'


class MusicListSerializer(serializers.ModelSerializer):

    class Meta:
        model = Music
        fields = ('title',)


