from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework import status
from rest_framework.response import Response
from .models import Artist, Music

from music.serializers import ArtistListSerializer, ArtistSerializer, MusicSerializer, MusicListSerializer
from django.shortcuts import get_list_or_404, get_object_or_404

# Create your views here.


# 모든 가수의 id와 name 반환
@api_view(['GET','POST'])
def artist_all(request):
    if request.method == 'GET':
        artists = Artist.objects.all()
        # artists = get_list_or_404(Artist)
        serializer = ArtistListSerializer(artists, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = ArtistSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(status=status.HTTP_201_CREATED)
        return Response(status=status.HTTP_400_BAD_REQUEST)


# 아티스트 정보 관리(삭제, 추가, 조회)
@api_view(['DELETE','POST','GET', 'PUT'])
def artist_detail(request, artist_pk):
    # artist = Artist.objects.get(pk=artist_pk)
    artist = get_object_or_404(Artist, pk=artist_pk)

    # 아티스트 삭제
    if request.method == 'DELETE':
        artist.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    # 아티스트 추가
    elif request.method == 'POST':
        serializer = ArtistListSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

    # 아티스트 조회
    elif request.method == 'GET':
        music_set = artist.music_set.all()    # 역참조 코드
        serializer = MusicSerializer(music_set, many=True)
        return Response(serializer.data)

    # 아티스트 수정
    elif request.method == 'PUT':
        serializer = ArtistListSerializer(artist, data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)


# 모든 음악의 id와 title 반환
@api_view(['GET'])
def music_all(request):
    if request.method == 'GET':
        music = Music.objects.all()
        serializer = MusicSerializer(music, many=True)
        return Response(serializer.data)


#  특정 음악의 모든 컬럼
@api_view(['DELETE','PUT'])
def music_detail(request, music_pk):
    music = Music.objects.get(pk=music_pk)

    if request.method == 'DELETE':
        music.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    elif request.method == 'PUT':
        serializer = MusicSerializer(music, data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data)

    # elif request.method == 'POST':
    #     serializer = MusicListSerializer(data=request.data)
    #     if serializer.is_valid(raise_exception=True):
    #         serializer.save()
    #         return Response(serializer.data, status = status.HTTP_201_CREATED)

