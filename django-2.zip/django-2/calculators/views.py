from django.shortcuts import render

# Create your views here.
def calculation(request):
    return render(request, 'calculators/calculation.html')

def result(request):
    first = request.POST.get('first')
    second = request.POST.get('second')
    first = int(first)
    second = int(second)

    plus = first + second
    minus = first - second
    multiple = first * second
    divide = "계산할 수 없습니다" if second == 0 else first / second
    context = {
        'first' : first,
        'second' : second,
        'plus' : plus,
        'minus' : minus,
        'multiple' : multiple,
        'divide' : divide,
    }
    return render(request, 'calculators/result.html', context)